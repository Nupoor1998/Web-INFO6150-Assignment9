import profile from "../Img/profile.jpg";

const Company = [
  {
    title: "Name",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet suscipit enim, non scelerisque ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris sollicitudin odio est, id euismod nunc ornare in. Etiam a arcu eros. Nullam condimentum posuere velit, ut sodales erat tempus eu. Aenean varius in lectus et vestibulum. Donec convallis nisi tortor, id consectetur dolor sodales vitae. Morbi mollis molestie nulla, id interdum sapien laoreet vitae. Vestibulum id tincidunt nibh. Proin quis ultricies libero, non ultricies metus. Vivamus sed magna leo.",
    subtext: "Co-Founder & CEO",
    photo: profile,
  },
  {
    title: "Name",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet suscipit enim, non scelerisque ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris sollicitudin odio est, id euismod nunc ornare in. Etiam a arcu eros. Nullam condimentum posuere velit, ut sodales erat tempus eu. Aenean varius in lectus et vestibulum. Donec convallis nisi tortor, id consectetur dolor sodales vitae. Morbi mollis molestie nulla, id interdum sapien laoreet vitae. Vestibulum id tincidunt nibh. Proin quis ultricies libero, non ultricies metus. Vivamus sed magna leo.",
    subtext: "Co-founder & COO",
    photo: profile,
  },
  {
    title: "Name",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet suscipit enim, non scelerisque ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris sollicitudin odio est, id euismod nunc ornare in. Etiam a arcu eros. Nullam condimentum posuere velit, ut sodales erat tempus eu. Aenean varius in lectus et vestibulum. Donec convallis nisi tortor, id consectetur dolor sodales vitae. Morbi mollis molestie nulla, id interdum sapien laoreet vitae. Vestibulum id tincidunt nibh. Proin quis ultricies libero, non ultricies metus. Vivamus sed magna leo.",
    subtext: "CTO",
    photo: profile,
  },
];

export default Company;
